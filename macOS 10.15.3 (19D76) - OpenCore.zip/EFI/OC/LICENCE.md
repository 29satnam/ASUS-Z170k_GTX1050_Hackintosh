This work is published for informational use only by Barijaona R.

Any component shown here retains its own licence, and you are required to thoroughly check its terms of use.

Subsequent texts and adaptations are covered by the [Creative Commons Attribution-ShareAlike License](https://creativecommons.org/licenses/by-sa/3.0/); additional terms may apply.